# Website Update Instructions

## What changed and why

Your site was last updated Nov 19, 2025. It still referenced AlphaCT, the "pivot to research" framing, listed your location as VA, and had a broken contact link. None of your 2026 work was represented.

## Files to replace or add

### Replace these files (overwrite existing):
1. `_pages/about.md` — Complete rewrite. Leads with current role and research question, not "pivot" language.
2. `_pages/cv.md` — Updated with 2026 preprints, PyHealth maintainer role, MatScope, correct job title.
3. `_data/navigation.yml` — Adds "Research" to nav bar, fixes broken contact mailto link.

### Add these new files:
4. `_pages/research.md` — **NEW PAGE.** Groups your papers by theme (representations, guarantees, inference, networks, physics, software). This is the spine made visible.
5. `_posts/2026-03-07-when-is-a-learned-signal-trustworthy.md` — **NEW BLOG POST.** The research agenda post anchored in CPD.

### Delete these files:
6. `_posts/2012-08-14-blog-post-1.md` — Lorem ipsum placeholder
7. `_posts/2013-08-14-blog-post-2.md` — Lorem ipsum placeholder
8. `_posts/2014-08-14-blog-post-3.md` — Lorem ipsum placeholder
9. `_posts/2015-08-14-blog-post-4.md` — Lorem ipsum placeholder

### Edit in _config.yml (manual — just change these lines):
- Change `location:` from `VA` to `Tennessee`
- Change `bio:` / tagline from `ML Research Engineer | Model optimization, mechanistic interpretability, RL` to `ML Engineer & Independent Researcher`
- Make sure `email:` is `joshsteier@gmail.com` (not `your.email@gmail.com`)

## Quick deploy

```bash
cd joshuasteier.github.io

# Copy new/updated files
cp [downloaded]/_pages/about.md _pages/about.md
cp [downloaded]/_pages/cv.md _pages/cv.md
cp [downloaded]/_pages/research.md _pages/research.md
cp [downloaded]/_data/navigation.yml _data/navigation.yml
cp [downloaded]/_posts/2026-03-07-when-is-a-learned-signal-trustworthy.md _posts/

# Delete placeholder posts
rm _posts/2012-08-14-blog-post-1.md
rm _posts/2013-08-14-blog-post-2.md
rm _posts/2014-08-14-blog-post-3.md
rm _posts/2015-08-14-blog-post-4.md

# Edit _config.yml manually (location, bio, email)

# Commit and push
git add -A
git commit -m "Major site update: 2026 papers, research page, blog post, current bio"
git push
```

Site should rebuild on GitHub Pages within 1-2 minutes.

## What the site now communicates

- **About:** You're a working ML engineer who does independent research on a coherent question
- **Research:** Papers grouped by theme, not chronology — the spine is visible
- **Blog:** One real post making the research agenda explicit, no more lorem ipsum
- **CV:** Accurate, current, includes everything through March 2026
- **Navigation:** Research page is accessible, contact link works
